using System;
using System.Collections.Generic;
namespace RecipeManagement.Core;

/// <summary>
/// Part A implementation of the recipe-management system.
/// Uses the five nominated collections for their assigned roles:
///   Dictionary<int, Recipe> - recipe catalogue (primary lookup by ID)
///   List<string>            - shopping list of ingredient strings
///   LinkedList<int>         - cooking plan (recipe IDs in cook order)
///   Stack<int>              - history of recently removed plan recipes
///   Queue<string>           - active recipe's cooking instructions
/// </summary>
public sealed class RecipeManager : IRecipeManager
{
    private readonly Dictionary<int, Recipe> _recipes = new();
    private readonly List<string> _shoppingList = new();
    private readonly LinkedList<int> _cookingPlan = new();
    private readonly Stack<int> _removedRecipes = new();
    private readonly Queue<string> _instructionQueue = new();
    private readonly HashSet<int> _savedRecipes = new();

    public RecipeManager(IEnumerable<Recipe> recipes)
    {
        if (recipes is null)
        {
            throw new ArgumentNullException(nameof(recipes));
        }

        foreach (Recipe? recipe in recipes)
        {
            if (recipe is null)
            {
                throw new ArgumentException("Recipe collection contains a null entry.", nameof(recipes));
            }

            if (recipe.Id <= 0)
            {
                throw new ArgumentException($"Recipe ID must be positive (got {recipe.Id}).", nameof(recipes));
            }

            if (string.IsNullOrWhiteSpace(recipe.Title))
            {
                throw new ArgumentException($"Recipe {recipe.Id} has a blank title.", nameof(recipes));
            }

            if (!_recipes.TryAdd(recipe.Id, recipe))
            {
                throw new ArgumentException($"Duplicate recipe ID: {recipe.Id}.", nameof(recipes));
            }
        }
    }
    public int RecipeCount => _recipes.Count;
    public int ShoppingItemCount => _shoppingList.Count;
    public int CookingPlanCount => _cookingPlan.Count;
    public int PendingInstructionCount => _instructionQueue.Count;
    public int RemovedRecipeCount => _removedRecipes.Count;

    public bool AddRecipe(Recipe recipe) 
    {
        if (recipe is null)
        {
            throw new ArgumentNullException(nameof(recipe));
        }

        if (recipe.Id <= 0 || string.IsNullOrWhiteSpace(recipe.Title))
        {
            return false;
        }
        // TryAdd returns false when the key already exists, so duplicates are rejected.
        return _recipes.TryAdd(recipe.Id, recipe);
    }

    public Recipe? FindRecipe(int recipeId) =>
        _recipes.TryGetValue(recipeId, out Recipe? recipe) ? recipe : null;

    public bool RemoveRecipe(int recipeId)
    {
        // Cannot remove a recipe that is missing or still planned for cooking.
        if (!_recipes.ContainsKey(recipeId) || _cookingPlan.Contains(recipeId))
        {
            return false;
        }

        return _recipes.Remove(recipeId);
    }

    public int AddIngredientsToShoppingList(int recipeId)
    {
        if (!_recipes.TryGetValue(recipeId, out Recipe? recipe))
        {
            return 0;
        }
        foreach (string ingredient in recipe.Ingredients)
        {
            _shoppingList.Add(ingredient);
        }
        return recipe.Ingredients.Count;
    }

    // Return a copy so callers cannot mutate the internal list.
    public IReadOnlyList<string> GetShoppingList() => _shoppingList.ToList();
    public void ClearShoppingList() => _shoppingList.Clear();

    public bool AddRecipeToCookingPlan(int recipeId)
    {
        //Only a known recipe must appear, that too only once
        if (!_recipes.ContainsKey(recipeId) || _cookingPlan.Contains(recipeId))
        {
            return false;
        }
        _cookingPlan.AddLast(recipeId);
        return true;
    }

    public bool RemoveRecipeFromCookingPlan(int recipeId)
    {
        if (!_cookingPlan.Remove(recipeId))
        {
            return false;
        }
        _removedRecipes.Push(recipeId);
        return true;
    }
    public bool RestoreLastRemovedRecipe()
    {
        if (_removedRecipes.Count == 0)
        {
            return false;
        }

        int recipeId = _removedRecipes.Pop();

        if (!_recipes.ContainsKey(recipeId) || _cookingPlan.Contains(recipeId))
        {
            return false;
        }

        _cookingPlan.AddLast(recipeId);
        return true;
    }

    public int? PeekLastRemovedRecipe() =>
        _removedRecipes.Count == 0 ? null : _removedRecipes.Peek();

    public IReadOnlyList<int> GetCookingPlan() => _cookingPlan.ToList();
        
    public bool StartCooking(int recipeId)
    {
        if (!_recipes.TryGetValue(recipeId, out Recipe? recipe) || recipe.Instructions.Count == 0)
        {
            return false;
        }
        
        _instructionQueue.Clear();
        foreach (string instruction in recipe.Instructions)
        {
            _instructionQueue.Enqueue(instruction);
        }
        return true;
    }

    public string? PeekNextInstruction() =>
        _instructionQueue.Count == 0 ? null : _instructionQueue.Peek();

    public string? CompleteNextInstruction() =>
        _instructionQueue.Count == 0 ? null: _instructionQueue.Dequeue();

    public IReadOnlyList<Recipe> SearchByTitle(string searchText)
    {
        // A blank search returns every recipe.
        if (string.IsNullOrWhiteSpace(searchText))
        {
            return _recipes.Values.ToList();
        }

        return _recipes.Values
            .Where(recipe => recipe.Title.Contains(searchText, StringComparison.OrdinalIgnoreCase))
            .ToList();
    }
       

    public IReadOnlyList<Recipe> SearchByIngredient(string searchText)
    {
        // A blank search returns every recipe.
        if (string.IsNullOrWhiteSpace(searchText))
        {
            return _recipes.Values.ToList();
        }
        
        return _recipes.Values
            .Where(recipe => recipe.Ingredients
                .Any(ingredient => ingredient.Contains(searchText, StringComparison.OrdinalIgnoreCase)))
            .ToList();
    }


    public IReadOnlyList<Recipe> GetHighestProteinRecipes(int count)
    {
        // A zero or negative request returns nothing.
        if (count <= 0)
        {
            return new List<Recipe>();
        }

        return _recipes.Values
            .Where(recipe => recipe.Nutrition?.ProteinG is not null)
            .OrderByDescending(recipe => recipe.Nutrition!.ProteinG)
            .Take(count)
            .ToList();
    }


    public bool AddSavedRecipe(int recipeId)
    {
        // Only an existing recipe can be saved
        if (!_recipes.ContainsKey(recipeId))
        {
            return false;
        }

        // HashSet.Add returns false if the ID is already saved, so duplicates are rejected
        return _savedRecipes.Add(recipeId);
    }

    public bool RemoveSavedRecipe(int recipeId) => _savedRecipes.Remove(recipeId);
    

    public bool IsRecipeSaved(int recipeId) => _savedRecipes.Contains(recipeId);
        

    public IReadOnlyList<int> GetSavedRecipes() => _savedRecipes.ToList();

}
